function CloseNav(){
    document.getElementById('mysidenav').style.width = '0px';
    
}

function OpenNav(){
    document.getElementById('mysidenav').style.width = '250px';
    
}

$(document).ready(function(){
    $('.slider_wrapper').slick({
        centerMode: true,
        centerPadding: '60px',
        slidesToShow: 2,
        arrows: false,
        dots: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 1000,
        responsive: [
            {
              breakpoint: 768,
              settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '20px',
                slidesToShow: 1
              }
            },
           
            {
                breakpoint: 480,
                settings: {
                  arrows: false,
                  centerMode: true,
                  centerPadding: '20px',
                  slidesToShow: 1
            } 
        } 
        ]
    });
  
});

// service slider in mob

// $(document).ready(function(){
//     $('.serv_box_wrapper').slick({
//         slidesToShow: 1,
//         slidesToScroll: 1,
//         arrows: false,
//         dots: false,
//         autoplay: true,
//         autoplaySpeed: 2000,
//         speed: 1000,
//         responsive: [
//           {
//             breakpoint: 9999,
//             settings: "unslick"
//         },

//             {
//               breakpoint: 992,
//               settings: {
//                 slidesToShow: 1,
//                 slidesToScroll: 1
//               }
//             }      
//           ]

//       });

// });

// button animation


// Wrap every letter in a span
var textWrapper = document.querySelector('.ml6 .letters');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<a class='letter'>$&</a>");

let animation = anime.timeline({loop: true})
animation.add({
    targets: '.ml6 .letter',
    translateY: ["1.1em", 0],
    translateZ: 0,
    duration: 750,
    delay: (el, i) => 50 * i
  }).add({
    targets: '.ml6',
    duration: 1000,
    easing: "easeOutExpo",
    delay: 1000
  });
